using UnityEngine;

public class MultiChoiceOption : MonoBehaviour
{
    public string choiceName;
}
